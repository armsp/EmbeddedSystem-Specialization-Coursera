/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file <Add File Name> 
 * @brief <Add Brief Description Here >
 *
 * <Add Extended Description Here>
 *
 * @author <Add FirsName LastName>
 * @date <Add date >
 *
 */



#include <stdio.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

unsigned char print_mean(unsigned char *, int );
unsigned char print_maximum(unsigned char *, int );
unsigned char print_minimum(unsigned char *, int );
unsigned char print_median(unsigned char *, int );
void print_statistics(unsigned char *);
void print_array(unsigned char *, int );
void sort_array(unsigned char *, int );

void main() {

  unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,
                              114, 88,   45,  76, 123,  87,  25,  23,
                              200, 122, 150, 90,   92,  87, 177, 244,
                              201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};

  print_statistics(test);

}

//PRINT MEAN
unsigned char print_mean(unsigned char *array, int arrayLength ){
	unsigned int sum = 0;
	int i = 0;
	for (i=0;i<arrayLength;i++){
		sum += *(array+i);
	}
	return sum/arrayLength;
}

//PRINT MAXIMUM
unsigned char print_maximum(unsigned char *array, int arrayLength){
	int max = *(array);
	int i = 0;
	for(i=0;i<arrayLength;i++){
		if(max<*(array+i))
			max = *(array+i);
	}
	return max;
}

//PRINT MINIMUM
unsigned char print_minimum(unsigned char *array, int arrayLength){
	int min = *(array);
	int i = 0;
	for (i=0;i<arrayLength;i++){
		if(min>*(array+i))
			min = *(array+i);
		}
	return min;
}

//SORT ARRAY
void sort_array(unsigned char *array, int arrayLength){
	int temp,i,j;
	for(j=0;j<arrayLength-1;j++){
		for (i=0;i<arrayLength-1;i++){
			if(*(array+i)<*(array+i+1)){
				temp = *(array+i);
				*(array+i) = *(array+i+1);
				*(array+i+1) = temp;
			}
		}

	}

}

//PRINT MEDIAN
unsigned char print_median(unsigned char *array, int arrayLength){
	int median;
	median = *(array+(arrayLength/2)) + *(array+(arrayLength/2-1));
	return median/2;
}

//PRINT ARRAY
void print_array(unsigned char *array, int arrayLength){
	int i=0;
	for (i = 0; i<arrayLength; i++){
		printf("%u\t",*(array+i));
	}
}

//PRINT STATISTICS
void print_statistics(unsigned char *array){
	print_array(array, SIZE);
	unsigned char max = print_maximum(array, SIZE);
	printf("\nMax of the array is %u",max);
	unsigned char min = print_minimum(array, SIZE);
	printf("\nMin of the array is %u",min);
	unsigned char mean = print_mean(array, SIZE);
	printf("\nMean of the array is %u",mean);
	sort_array(array,SIZE);
	unsigned char median = print_median(array, SIZE);
	printf("\nMedian of the array is %u",median);
	printf("\nAfter sorting the array elements look as follows\n");
	print_array(array, SIZE);
}