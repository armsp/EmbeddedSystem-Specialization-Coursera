#include <stdint.h>
#include "memory.h"

uint8_t my_itoa(int32_t data, uint8_t * ptr, uint32_t base) {
  uint8_t i = 0;
  uint8_t sign = 0;
  if (data < 0) {
    sign = 1;
    data = -1*data;
  }
  while(data>0){
    *(ptr+i) = '0' + (data%base);
    i++;
    data = data/base;
  }
  *(ptr+i) = '\0';
  if(sign) {
    *(ptr+i) = '-';
    *(ptr+i+1) = '\0';
    my_reverse(ptr, i+1);
    return i+1;
  }
  my_reverse(ptr, i);
  return i;
}

int32_t my_atoi(uint8_t * ptr, uint8_t digits, uint32_t base) {
  int32_t sign = 1;
  int32_t num = 0;
  if(*ptr == '-') {
    sign = -1;
    ptr++;
    --digits;
  }

  while(digits) {
    num = num*base + (*ptr - '0');
    ptr++;
    digits--;
  }
  return (num*sign);
}
