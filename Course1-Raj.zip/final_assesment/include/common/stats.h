/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file <Add File Name> 
 * @brief <Add Brief Description Here >
 *
 * <Add Extended Description Here>
 *
 * @author <Add FirsName LastName>
 * @date <Add date >
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

/* Add Your Declarations and Function Comments here */ 
//void print_statistics(unsigned char * array);

/**
*@brief Prints the elements of an array
*This function takes input a pointer to an array and the array length.
*It prints the elements of the array as is.
*It does not return anything.
*
*@param Pointer to the array
*@param array length
*
@return Nothing
*/
void print_array(unsigned char * array, int arrayLength);

/**
*@brief Finds the mean of elements of the given array.
*This function takes input a pointer to the array and the array length.
*It returns the calculated mean of the elements.
*
*@param Pointer to the array
*@param array length
*
*@return Calculated mean
*/
unsigned char find_mean(unsigned char *array, int arrayLength);

/**
*@brief Finds the median of elements of the given array.
*This function takes input a pointer to the array and the array length.
*It returns the calculated median of the elements.
*
*@param Pointer to the array
*@param array length
*
*@return Calculated median
*/
unsigned char find_median(char * array, int arrayLength);

/**
*@brief Finds the maximum element of the given array.
*This function takes input a pointer to the array and the array length.
*It returns the maximum element.
*
*@param Pointer to the array
*@param array length
*
*@return Maximum element.
*/
unsigned char find_maximum(unsigned char * array, int arrayLength);

/**
*@brief Finds the minimum element of the given array.
*This function takes input a pointer to the array and the array length.
*It returns the minimum element.
*
*@param Pointer to the array
*@param array length
*
*@return Minimum element.
*/
unsigned char find_minimum(unsigned char * array, int arrayLength);

/**
*@brief Sorts the elements of an array.
*This function takes input a pointer to an array and the array length.
*It implements bubble sort to sort the elements of the array in descending order.
*It does not return anything.
*
*@param Pointer to the array
*@param array length
*
*@return Nothing
*/
void sort_array(unsigned char * array, int arrayLength);

#endif /* __STATS_H__ */
