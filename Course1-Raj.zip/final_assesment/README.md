Make follows the following rules - 

1) COURSE1 switch is enabled by default. 
   If you want to test it just give any input other than COURSE1 to SWITCH on commandline.
   Eg: make build SWITCH=NOTCOURSE1 or make build SWITCH=ANY_RANDOM_THING

2) VERBOSE flag is DISABLED by default. If you want to test it then enable it by using the
   VFLAG variable in makefile. 
   Eg: make build VFLAG=VERBOSE will print all the details by enabling the VERBOSE flag.

3) All combinations of SWITCH and VFLAG work.
   Eg: make build SWITCH=NOTCOURSE1
       make build VFLAG=VERBOSE
       make build SWITCH=NOT_COURSE1 VFLAG=VERBOSE
       make build SWITCH=COURSE1 VFLAG=NOT_VERBOSE
